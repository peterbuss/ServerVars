export const process = {
    env: {
        OPENAI_API_KEY: "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"
    }
} 